var stocks = [];
function saveModalData() {
    let stockName = document.getElementById('sname').value;
    let stockPrice = document.getElementById('sprice').value;

    console.log(stockName, stockPrice);
    
    if(stocks.length > 0) {
        //check the stock is existing or not
        let stock = stocks.filter(item => item.name == stockName);
        console.log(stock);
        if(stock.length == 0) {
            //first time
            let obj = {
                name: stockName,
                startPrice: stockPrice,
                openPrice: stockPrice,
                closePrice: '',
                previousPrices: [stockPrice]
            };
            stocks.push(obj);
        } else {
            if(stock[0].closePrice == '') {
                stock[0].closePrice = stockPrice;
            } else {
                stock[0].openPrice = stock[0].closePrice;
                stock[0].closePrice = stockPrice;
            }

            stock[0].previousPrices.push(stockPrice);
        }
    } else {
        //first time
        let obj = {
            name: stockName,
            startPrice: stockPrice,
            openPrice: stockPrice,
            closePrice: '',
            previousPrices: [stockPrice]
        };
        stocks.push(obj);
    }
    renderStockTable();
    closeModal();
}

function renderStockTable(orderByPrice = false) {
    document.getElementById('tableDiv').style.display = 'block';
    let tbody = document.getElementById('tbody');


    let content = '';
    stocks.forEach(stock => {
        let fluctuation = '';
        let arrowSymbol = '';
        stock.fluctuation = 0;

        if(stock.closePrice != '') {
           fluctuation = ((parseFloat(stock.closePrice) - parseFloat(stock.openPrice))/parseFloat(stock.openPrice))*100;
           fluctuation = fluctuation.toFixed(2);
           
           stock.fluctuation = fluctuation;
           if(fluctuation > 0) {
               arrowSymbol = '<img src="icons/arrowup.png" class="icon" alt="Increase" />';
            } else if(fluctuation < 0) {
               arrowSymbol = '<img src="icons/downarrow.png" class="icon" alt="Decrease" />';
           }
        }

        // table header => Company, Open Price, Current Price, Price Fluctuation
        content += `<tr>
                        <td>${stock.name}</td>
                        <td>${stock.openPrice}</td>
                        <td>${stock.closePrice}</td>
                        <td>
                            ${fluctuation} ${arrowSymbol}
                        </td>
                   </tr>`;
    });

    tbody.innerHTML = content;
}

function closeModal() {
    let modals = document.querySelectorAll('.modal');
    modals.forEach(modal => modal.style.display = 'none');
    document.querySelector('#rest').style.display = 'block';
}

function openModal() {
    document.querySelector('.modal').style.display = 'block';
    document.querySelector('#rest').style.display = 'none';
}

function showSummary() {
    if(stocks.length > 0) {
        let modal = document.getElementById('summaryModal');
        document.querySelector('#rest').style.display = 'none';
        modal.style.display = 'block';

        //get top gainer
        let myStocks = [...stocks];
        myStocks.sort((stock1, stock2) => stock1.fluctuation - stock2.fluctuation);

        console.log(myStocks);

        console.log(myStocks[0].name+' is looser');
        console.log(myStocks[myStocks.length - 1].name+' is gainer');

        let content = '<div class="float-right close-icon" onclick="closeModal();" title="Close">X</div>';

        content += `<span class="gainer">${myStocks[myStocks.length - 1].name} is Gainer</span>`;
        content += `<span class="looser">${myStocks[0].name} is looser</span>`;

        modal.innerHTML = content;

    }

}